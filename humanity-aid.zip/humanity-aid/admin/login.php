<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($email && $password) {
        $stmt = $mysqli->prepare("SELECT id,name,password,role FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->bind_result($id,$name,$hash,$role);
        if ($stmt->fetch()) {
            if (password_verify($password, $hash) && $role === 'admin') {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $id;
                $_SESSION['admin_name'] = $name;
                header('Location: dashboard.php'); exit;
            }
        }
        $stmt->close();
        $error = 'Invalid credentials or not an admin.';
    } else {
        $error = 'Please enter email and password.';
    }
}
?>
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Admin Login</title></head><body>
<h2>Admin Login</h2>
<?php if ($error) echo '<p style="color:red">' . htmlspecialchars($error) . '</p>'; ?>
<form method="post">
    <label>Email: <input name="email" type="email"></label><br>
    <label>Password: <input name="password" type="password"></label><br>
    <button type="submit">Login</button>
</form>
</body></html>
