<?php
session_start();
if (empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php'); exit;
}
require_once __DIR__ . '/../includes/db.php';

$msg = '';
$active_tab = $_GET['tab'] ?? 'events';

// Handle event creation
if ($_POST['action'] === 'create_event' && !empty($_POST['title'])) {
    $title = $_POST['title'];
    $description = $_POST['description'] ?? '';
    $event_date = $_POST['event_date'] ?? null;
    $event_time = $_POST['event_time'] ?? null;
    $location = $_POST['location'] ?? '';
    
    $image = '';
    if (!empty($_FILES['event_image']['name'])) {
        $file = $_FILES['event_image'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $fname = 'event_' . time() . '.' . $ext;
        $path = __DIR__ . '/../img/events/' . $fname;
        if (move_uploaded_file($file['tmp_name'], $path)) {
            $image = 'img/events/' . $fname;
        }
    }
    
    $stmt = $mysqli->prepare("INSERT INTO events (title,description,event_date,event_time,location,image,created_by) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param('ssssssl', $title, $description, $event_date, $event_time, $location, $image, $_SESSION['admin_id']);
    if ($stmt->execute()) {
        $msg = 'Event created successfully!';
    } else {
        $msg = 'Error: ' . $stmt->error;
    }
    $stmt->close();
}

// Handle post creation
if ($_POST['action'] === 'create_post' && !empty($_POST['post_title'])) {
    $post_title = $_POST['post_title'];
    $content = $_POST['content'] ?? '';
    
    $image = '';
    if (!empty($_FILES['post_image']['name'])) {
        $file = $_FILES['post_image'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $fname = 'post_' . time() . '.' . $ext;
        $path = __DIR__ . '/../img/posts/' . $fname;
        if (move_uploaded_file($file['tmp_name'], $path)) {
            $image = 'img/posts/' . $fname;
        }
    }
    
    $stmt = $mysqli->prepare("INSERT INTO posts (title,content,image,created_by) VALUES (?,?,?,?)");
    $stmt->bind_param('sssi', $post_title, $content, $image, $_SESSION['admin_id']);
    if ($stmt->execute()) {
        $msg = 'Post created successfully!';
    } else {
        $msg = 'Error: ' . $stmt->error;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f5f5f5; padding: 20px 0; }
        .admin-container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 5px; }
        .admin-header { margin-bottom: 30px; border-bottom: 2px solid #ddd; padding-bottom: 15px; }
        .form-section { display: none; }
        .form-section.active { display: block; }
        .btn-tab { margin-right: 5px; margin-bottom: 15px; }
    </style>
</head>
<body>
<div class="admin-container">
    <div class="admin-header">
        <h2>Admin Dashboard</h2>
        <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['admin_name']); ?></strong></p>
    </div>
    
    <?php if (!empty($msg)): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    
    <div class="nav-tabs" role="tablist" style="margin-bottom:20px;">
        <button class="btn btn-primary btn-tab" onclick="showTab('events')">Create Event</button>
        <button class="btn btn-primary btn-tab" onclick="showTab('posts')">Create Post</button>
        <a href="logout.php" class="btn btn-danger btn-tab">Logout</a>
        <a href="/" class="btn btn-secondary btn-tab">Visit Site</a>
    </div>
    
    <!-- Create Event Form -->
    <div id="events" class="form-section active">
        <h3>Create New Event</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create_event">
            <div class="form-group">
                <label>Event Title *</label>
                <input type="text" class="form-control" name="title" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" name="description" rows="4"></textarea>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>Event Date</label>
                    <input type="date" class="form-control" name="event_date">
                </div>
                <div class="form-group col-md-6">
                    <label>Event Time</label>
                    <input type="time" class="form-control" name="event_time">
                </div>
            </div>
            <div class="form-group">
                <label>Location</label>
                <input type="text" class="form-control" name="location">
            </div>
            <div class="form-group">
                <label>Event Image</label>
                <input type="file" class="form-control" name="event_image" accept="image/*">
            </div>
            <button type="submit" class="btn btn-success">Create Event</button>
        </form>
    </div>
    
    <!-- Create Post Form -->
    <div id="posts" class="form-section">
        <h3>Create New Post/Article</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create_post">
            <div class="form-group">
                <label>Article Title *</label>
                <input type="text" class="form-control" name="post_title" required>
            </div>
            <div class="form-group">
                <label>Content</label>
                <textarea class="form-control" name="content" rows="6"></textarea>
            </div>
            <div class="form-group">
                <label>Article Image</label>
                <input type="file" class="form-control" name="post_image" accept="image/*">
            </div>
            <button type="submit" class="btn btn-success">Create Post</button>
        </form>
    </div>
</div>

<script>
function showTab(tabName) {
    const tabs = document.querySelectorAll('.form-section');
    tabs.forEach(t => t.classList.remove('active'));
    document.getElementById(tabName).classList.add('active');
}
</script>

</body>
</html>
