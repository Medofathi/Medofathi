<?php
/* Create an admin user for the site.
   Usage: open this file in browser, fill username/email/password and submit.
   After creating admin, delete this file for security. */
require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($name && $email && $password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $mysqli->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?, 'admin')");
        $stmt->bind_param('sss', $name, $email, $hash);
        if ($stmt->execute()) {
            $msg = 'Admin created successfully. Delete this file now.';
        } else {
            $msg = 'Error: ' . $stmt->error;
        }
        $stmt->close();
    } else {
        $msg = 'Please fill all fields.';
    }
}
?>
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Create Admin</title></head><body>
<h2>Create Admin Account</h2>
<?php if (!empty($msg)) echo '<p>' . htmlspecialchars($msg) . '</p>'; ?>
<form method="post">
    <label>Name: <input name="name"></label><br>
    <label>Email: <input name="email" type="email"></label><br>
    <label>Password: <input name="password" type="password"></label><br>
    <button type="submit">Create Admin</button>
</form>
<p>After creating the admin, remove this file for security: admin/create_admin.php</p>
</body></html>
