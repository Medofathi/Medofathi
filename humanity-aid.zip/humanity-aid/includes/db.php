<?php
// Database connection
// Update DB_USER and DB_PASS as needed for your environment (XAMPP default: root / "")
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'humanity-aid');

$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_errno) {
    error_log("MySQL connection failed: " . $mysqli->connect_error);
    die('Database connection failed.');
}

// set charset
$mysqli->set_charset('utf8mb4');

// helper: escape
function e($s) { global $mysqli; return htmlspecialchars($mysqli->real_escape_string($s), ENT_QUOTES, 'UTF-8'); }

?>
